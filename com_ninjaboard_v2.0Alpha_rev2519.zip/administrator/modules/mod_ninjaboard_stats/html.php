<?php defined( 'KOOWA' ) or die( 'Restricted access' );
/**
 * @package		Ninjaboard
 * @copyright	Copyright (C) 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */

class ModNinjaboard_statsHtml extends ModDefaultHtml
{
	//Do nothing
}