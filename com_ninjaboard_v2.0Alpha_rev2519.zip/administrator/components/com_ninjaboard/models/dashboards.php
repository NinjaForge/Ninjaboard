<?php defined( 'KOOWA' ) or die( 'Restricted access' );
/**
 * @todo Dummy model until Mathias figure out a better way to do it
 */
class ComNinjaboardModelDashboards extends NinjaModelDashboards
{
	//Do nothing
}