<?php defined( 'KOOWA' ) or die( 'Restricted access' );
/**
 * @package		Ninja
 * @copyright	Copyright (C) 2011 NinjaForge. All rights reserved.
 * @license 	GNU GPLv3 <http://www.gnu.org/licenses/gpl.html>
 * @link     	http://ninjaforge.com
 */

/**
 * Template Toolbar Helper
 */
class ComNinjaboardTemplateHelperToolbar extends NinjaTemplateHelperToolbar
{
    //Do nothing
}