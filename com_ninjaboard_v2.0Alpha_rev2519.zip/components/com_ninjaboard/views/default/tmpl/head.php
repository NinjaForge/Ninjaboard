<? defined( 'KOOWA' ) or die( 'Restricted access' ) ?>

<link rel="stylesheet" href="/pagination.css" />
<link rel="stylesheet" href="/toolbar.css" />
<link rel="stylesheet" href="/site.css" />

<script type="text/javascript" src="/jquery/jquery.js"></script>
<?= @helper('behavior.mootools') ?>
<?= @ninja('behavior.ninja') ?>
<script type="text/javascript" src="media://lib_koowa/js/koowa.js"></script>
<script type="text/javascript" src="/toolbar.js"></script>
<script type="text/javascript" src="/site.js"></script>