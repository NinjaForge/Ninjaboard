<? defined( 'KOOWA' ) or die( 'Restricted access' ) ?>

<div class="header relative">
	<?= @$pagination ?>
</div>
<?= @template('list') ?>
<div class="footer relative">
	<?= @$pagination ?>
</div>